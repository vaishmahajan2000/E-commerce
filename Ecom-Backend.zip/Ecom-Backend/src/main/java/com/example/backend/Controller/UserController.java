package com.example.backend.Controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;



import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.Payload.UserDto;
import com.example.backend.Services.UserService;


@CrossOrigin(origins="*")
@RestController
@RequestMapping("/user")

public class UserController {
	
	/*
	@Autowired
	private PasswordEncoder passwordEncoder;
	*/
	
	@Autowired
	private ModelMapper mapper;
	@Autowired
	private UserService userServie;
	
	
	@PostMapping("/create")
	public ResponseEntity<UserDto> createUser(@RequestBody UserDto userDto){
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date=new Date();
		formatter.format(date);
		userDto.setDate(date);
		userDto.setActive(true);
		
		UserDto ud=this.userServie.create(userDto);
		return new ResponseEntity<UserDto>(ud,HttpStatus.CREATED);
	}
	
	@GetMapping("findById/{userId}")
	public ResponseEntity<UserDto> findUserById(@PathVariable int userId){
	
		UserDto byId=this.userServie.getByUserId(userId);
		return new ResponseEntity<UserDto>(byId,HttpStatus.FOUND);
	}
	
	@DeleteMapping("delete/{userId}")
	void deleteUserById(@PathVariable int userId){	
	this.userServie.delete(userId);	
	}
	
	@GetMapping("findAll")
	public ResponseEntity<List<UserDto>> findAllUsers(){
		List<UserDto> findall=this.userServie.getAll();
		return new ResponseEntity<List<UserDto>>(findall,HttpStatus.ACCEPTED);
	}
	
}
	
	
	